<?php


// Use If Statement to Check if we did actually submit the contact form
// Checking the POST method which is "submit"
if (isset($_POST['submit'])) {
    // script to send the email
    // getting data from contact form
    $name = $_POST['name'];
    $subject = $_POST['subject'];
    $mailFrom = $_POST['mail'];
    $message = $_POST['message'];

    
    $mailTo = "emuenzler@aol.com";
    $headers = "from: ".$mailFrom;
    $txt = "You have received an e-mail from ".$name.".\n\n" .$message;
    
    // PHP Function called "mail"
    // 3 parameters
    mail($mailTo, $subject, $txt, $headers);

    // Function to take us back to the home page
    header("location: contacts.php?mailsend");

}




/* NOTES

TODO Later I need to add Error handling to check and make sure the user types in the right info

1) PHP isset() Function
The isset() function checks whether a variable is set, which means that it has to be declared and is not NULL. This function returns true if the variable exists and is not NULL, otherwise it returns false.

2) $mailTo YOU CAN NOT SEND DIRECTLY TO GMAIL BECAUSE OF GMAIL'S / google
blocks the mail function built into PHP.
You can send to Gmail using a forward email from your hosting.

2) In $headers you have multiple options you can put where the email is from or you can put your website name
there is other options as well.


3) Use " \n " to jump down a line. 


*/