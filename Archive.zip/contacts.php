

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <!-- Keywords -->
    <meta name="description" content="Mulching Company for any type of commercial, government or private client!">
  <meta name="keywords" content="Land,Lot,Lot clearing, Land clearing, dozer, excavator, skid, steer, skidsteer, bucket, backhoe, dirt, dirt work, grading, grade, mobile, home, mobilehome, modular, manufactured, landscape, road, drive way, driveway, landscaping, sand, rock, gravel, clay, liner, mulch, mulching, underbrush, underbrushing, brush, brushing, shredding, chipping, chipper, mowing, forest, forestry, tree, removal, homesite, home site, prep, preparation, clean, cleaning, equipment, heavy equipment, trucking, truck, trailer, tools, Improvements, maintenance, right of way, row, R.O.W., easement, easements, electric easement, electricity easement, electrical easement, water line, well, hole, ditch, tank, pond, lake, creek, mesquite clearing, youpon clearing, concrete, foundation, demolition, building, house, home, septic system, cedar, yaupon, holly, rosebush, juniper, Harvard shin, blackbush, sandsage, saltcedar, hickory, hawthorn, supplejack, trumpet creeper, dewberry, coral-berry, little bluestem, silver bluestem, sand lovegrass, beaked panicum, three-awn, spranglegrass, tickclover, sumac, wax myrtle, Chinese holly, Chinese yaupon, bodark, oak, elm, pin oak, post oak, blackjack, tallot, pine, water, cottonwood, hackberry, honey locust, sorghum, cane, bamboo, vegetation, mitigation, erosion control, herbicide, leveling, Caldwell, Snook, Lyons, Milano, Brenham, Burton, Union Hill, Gay Hill, Quarry, Bryan, CollegeStation, BCS, Hogg, Dimebox, Lincoln, Warda, Franklin, Cookspoint, Smithville, Giddings, Zionville, Bastrop, Fedor, Forest Grove, Independence, Clay, Wilcox, Millican, Navasota, Anderson, Richards, Roans Prairie, Blackjack, Deanville, Minerva, Rockdale, Cameron, Hearne, Benchley, Wheelock, Wixon Valley, Brazos Valley, Kurten, Tabor, Reliance, New Tabor,  Steep Hollow, Mumford, Astin Junction Branchville Gause Calvert Jones Prarie Maysfield, Ben Arnold, Burlington, Clarkson, Tarrelton, Buckholts, Sharp, Davilla, Val Verde, San Gabriel, Laneport, Detmold, Thorndale, Thrall, Noack, Adina, Blue, Fedor, Manheim, Paige, Hills, Serbin, Camp Swift, Mcdade, Alum, Loebau, Leo, Creek, Upton, Winchester, Ledbetter, Waldeck, Carmine, Round Top, Warrenton, Nechanitz, Phillipsburg, Kenny, Bleiberville, Winedale, Ledbetter, Bremond, Gainger, Taylor, North Zulch, Normangee, Coupland, Elgin, Bartlett, Temple, Hutto, Bremond, Hare,">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="img/Quality_Improvements_favicon_Logo.png" type="image/gif" sizes="16x16">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css"
        integrity="sha384-REHJTs1r2ErKBuJB0fCK99gCYsVjwxHrSU0N7I1zl9vZbggVJXRMsv/sLlOAGb4M" crossorigin="anonymous">
    <!-- CSS STYLES -->
    <link rel="stylesheet" href="https://unpkg.com/swiper/css/swiper.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" media="screen and (max-width: 1024px)" href="css/mobile.css">

    <!-- text animation css -->
    <!-- <link rel="stylesheet" href="https://unpkg.com/tachyons/css/tachyons.min.css"> -->
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css"> -->
    <!-- <link rel="stylesheet" href="css/tachyons-animate.css"> -->


    <!-- Swiper Header Slider -->
    <!-- <link rel="stylesheet" href="/css/swiper.min.css"> -->
    <!-- <link rel="stylesheet" href="https://unpkg.com/swiper/css/swiper.min.css"> -->


    <title>Quality Mulching</title>
</head>



<body id="contact-us-body">


    <!-- Header Container -->

    <!-- Navbar-Black -->
    <div id="masthead" class="site-header">
        <nav class="header-container">

            <!-- Top Black Header Bar -->
            <div class="header-container_wrap">
                <div class="container">
                    <div class="items">
                        <div class="quality-logo">
                            <a href="index.html">
                                <img border="0" alt="quality-logo" src="img/Quality_Improvements_250PX_Logo.png" >
                            </a>
                            <!-- <img src="img/Quality_Improvements_250PX_Logo.png" alt="quality-logo"> -->
                            <p>Offering Quality work at a fair price to the Central Texas area.</p>
                        </div>
                        <div class="contact-info">
                            <div class="item">
                                <i class="fas fa-phone"></i>
                                <div class="contact-block__value-wrap">
                                    <p> Call Today</p>
                                    <p><strong>(979)-406-2042</strong></p>
                                </div>
                            </div>
                            <div class="item">
                                <i class="fas fa-clock"></i>
                                <div class="contact-block__value-wrap">
                                    <p>Mon-Fri:<strong> 7am to 7pm</strong></p>
                                    <p>Sat & Sun: 9am-4pm</p>
                                </div>
                            </div>
                            <div class="item">
                                <i class="fas fa-map-marker-alt"></i>
                                <p>Serving Central Texas</p>
                            </div>
                            <div class="item">
                               <!-- FACEBOOK BUTTON -->
                               <a href="https://www.facebook.com/tameyourterrain/">
                                    <button class="facebook-like">
                                        <i class="fab fa-facebook-f"></i>
                                        <p>LIKE US</p>
                                    </button>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            
            <!-- ======================== Bottom White header START ======================-->


            <div class="bottomnav" id="mybottomnav">
                <div class="container">
                    <div class="items">
                        <div class="item">
                            <nav class="mynav">

                                <!-- <a href="#home" class="active">Menu Click Here</a> -->
                                <!-- Hamburger -->
                                <ul>
                                    <div class="hamburger">
                                        <!-- <p class="active">Menu Click Here</p> -->
                                        <a href="javascript:void(0);" class="icon" onclick="myFunction()"><p>Menu Click Here </p>  &#9776;</a>
                                    </div>
                                    <li><a href="about.html">About</a></li>
                                    
                                    <!-- DROPDOWN MENU -->
                                    
                                        <li>
                                            <div class="dropdown">
                                                <button class="dropbtn">
                                                
                                                    Services <i class="fa fa-caret-down"></i>
                                                    
                                                </button>
                                                
                                                <div class="dropdown-content">
                                                    <a href="brush-mulching-land-clearing.html">Brush Mulching & Land Clearing</a>
                                                    <a href="mapping-measurement.html">Mapping & Measurement</a>
                                                    <a href="erosion-mitigation-driveways-roads.html">Erosion Mitigation / Driveways / Roads</a>
                                                    <a href="landscaping-drainage-management.html">Landscaping & Drainage Management</a>
                                                    <a href="foundation-pads.html">Foundation & Pads</a>
                                                    <a href="general-dirt-work.html">General Dirt Work & Tank Pond Trenching</a>
                                                    <a href="demolition-clean-up.html">Demolition & Clean Up</a>
                                                    <!-- <a href="septic-installation.html">Septic Installation</a> -->
                                                </div>
                                            </div>
                                        </li>
                                  
                                    <!-- DROPDOWN MENU END -->
                                    
                                    <li><a href="photo-gallery.html">Photo Gallery</a></li>
                                    <li><a href="video-example.html">Video Example</a></li>
                                    <li><a href="contacts.html">Contacts</a></li>
                                    <!-- <a href="javascript:void(0);" class="icon" onclick="myFunction()">&#9776;</a> -->
                                </ul>
                            </nav>
                            

                        </div>

                        <div class="item">
                            <i class="fas fa-search"></i>
                        </div>
                    </div>

                </div>
            </div>
            <span class="target"></span>

            <!-- ======================== Bottom White header END ======================-->
            
        </nav>
    </div>

    <!-- ============================ HEADER CONTAINER END =================================== -->


    <!-- BODY -->


    <!-- ========================= CONTACT US - HEADER IMAGE ====================================-->



        <section id="contact-us" class="bg-black py ">
            <div class="about-content py-2">  
                <div class="container">
                    <h1 class="l-heading">
                        <span>Contact Us</span>
                    </h1>  
                    
                </div>
            </div>
        </section>
  

<!-- ====================================== MAP ============================ -->


<section id="map" class="py-2">
    <div class="container">
        <iframe style="border: 0;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d219821.74253198647!2d-96.8523962139011!3d30.585597588172618!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x864439d75d056c37%3A0xa8eef1423a624b27!2sCaldwell%2C+TX+77836!5e0!3m2!1sen!2sus!4v1529983231784" width="100%" height="500" frameborder="0" allowfullscreen="allowfullscreen"></iframe>

    </div>
</section>


<section id="contacts-info" class="py-2">
            <div class="items">
                <div class="item">
                    <p class="m-heading"><strong>Contacts</strong></p>
                    <p class="lead"><strong>Eric Muenzler</strong></p>
                    <p class="lead"><strong>Address:</strong> Caldwell, Texas 77836</p>
                    <p class="lead"><strong>Phone</strong> (972) 406-2042</p>
                    <a class="lead text-black" href="mailto:Emuenzler@aol.com">Emuenzler@aol.com</a>
                </div>
               
               
                <!-- ==================  CONTACT FORM ========================-->
          
            <div class="contact-form bg-yellow p-2">
                <h2 class="m-heading">Contact us</h2>
                <p>Pleaes use the form below to contact us</p>
                


                <form action="contactform.php" method="POST" id="form" class="contact-form">
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" name="name" id="name" placeholder="Enter Name">
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="text" name="mail" id="email" placeholder="Enter Email">
                    </div>
                    <div class="form-group">
                        <label for="email">Subject</label>
                        <input type="text" name="subject" id="subject" placeholder="subject">
                    </div>
                    <div class="form-group">
                        <label for="message">Message</label>
                        <textarea type="text" name="message" rows="10" id="message" placeholder="Enter Message"></textarea>
                    </div>
                    <input type="submit" name="submit" class="btn btn-black" value="Send Email" >
                </form>
            </div>
            
            
        
</section>



<!-- ====================================== BLACK BOTTOM FOOTER ============================ -->

<section id="main-footer" class="bg-black py-3">
    <div class="container">
        <div class="items wrap">
            <div class="item">
                <img src="/img/Quality_Improvements_250PX_Logo.png" alt="Quality Mulching Logo">
                <p>We're proud of our input towards building the future ground up! Our mulching company is ready to complete any kind of project for any type of commercial, government or private client!</p>
            </div>
            <div class="item">
                <h3>Contacts</h3>
                <p> Caldwell, Texas 77836</p>
                <div class="email">
                    <a href="mailto:someone@example.com?Subject=Hello%20again" target="_top">Emuenzler@aol.com</a>
                </div>
                <div class="phone-number">
                    <i class="contact-block__icon fa fa-phone"></i>
                    <a href="tel:(979)-406-2042"><h3>(972)-406-2042</h3></a>
                </div>
            </div>
            <div class="item">
                <a href="https://www.facebook.com/tameyourterrain/">
                    <div class="facebook-like">
                        <h3>LIKE US</h3>
                        <i class="fab fa-facebook-f"></i>
                    </div>
                </a>
            </div>
            <div class="item">
                <h3 class="text-center">Working Hours</h3>
                <div class="work-hours-content">
                    <div class="content ">
                        <p>Weekdays: Mon. – Fri.
                            <br>
                            Working Hours: 7:00 AM – 7:00 PM</p>
                    </div>
                    <div class="content ">
                        <p>Weekdays: Sat. – Sun.
                            <br>
                        Working Hours: 9:00 AM – 4:00 PM</p>
                    </div>

                </div>
            </div>
        </div>
        <p class="text-center py-2">© 2020 Quality Improvements. All rights reserved. Privacy Policy - Cookies Policy</p>
    </div>
</section>



    <!-- CDN LINK -->
    <script src="https://unpkg.com/swiper/js/swiper.js"></script>
    <script src="js/swiper-slider.js"></script>
    <script src="js/main.js"></script>
    






</body>

</html>



<!-- 
    php email tutorial 8:59
YELLOW - #f7c51e
GREY - #363636
background white - #f6f6f6

 -->
